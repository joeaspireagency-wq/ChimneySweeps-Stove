# Ashcroft Chimney & Stove Co. – website prototype

A single-page, front-end-only prototype for a fictional UK chimney sweep and stove business (Stroud, Gloucestershire).

- `index.html` – the whole site in one file (CSS, JS and photos embedded; no build step)
- `.nojekyll` – makes GitHub Pages serve the page as-is

## Run locally
Open `index.html` in a browser.

## Publish on GitHub Pages
1. Push these files to the root of a repo (branch `main`).
2. Settings → Pages → Deploy from branch → `main` / root.

## Notes
- The "Get Your Free Quote" popup is front-end only and sends no data anywhere.
- The WhatsApp button and Privacy/Terms links are demo placeholders.
- Business name, people, reviews, ratings and prices are fictional demo content.
- Photos (owner, hero, before/after) are embedded in `index.html`; replace them with real photos before using for a real client.
- Phone number shown: +44 7340 847538.
